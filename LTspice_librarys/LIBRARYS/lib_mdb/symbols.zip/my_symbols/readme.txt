New symbols created for LTSpice. These are intended schematic
 only.
European elctrolytic symbol is referenced
 to the spice model for a capacitor.
Norton reference to I current source.

To refernce a symbol.
Edit Attribute window
In Prefix give spice letter e.g. R for resistor I for current source wtc
Then choose attribute window
Add Value Instance name  and Value

Move new components to 
/home/username/.wine/drive_c/Program Files/LTC/LTspiceIV/lib/sym   (linux)

(change "username" to your own username.)

C:\Program Files\LTC\LTspiceIV\lib\sym (windows)


 
