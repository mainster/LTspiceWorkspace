Original: Helmut Sennewald's impedance multiplier in
/Tut/examples/voltage_controlled_impedance.

The new circuits show correct noise in a .NOISE analysis.
