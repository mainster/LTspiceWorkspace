For explain see the url
www2.national.com/appbriefs/files/AppBrief115.pdf

Pascal