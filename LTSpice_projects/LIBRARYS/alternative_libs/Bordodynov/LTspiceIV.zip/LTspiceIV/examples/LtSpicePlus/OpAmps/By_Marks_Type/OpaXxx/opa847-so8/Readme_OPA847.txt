Files in this zip archive:
OPA847-so8.asy		828 bytes
OPA847_Test.asc		1481 bytes
OPA847-so8.sub		7114 bytes
Readme.txt	(this file)	500 bytes

This set is adapted from the Spice model for the OPA847
from the Texas Instruments web site, file sboc037a.zip.  The
key change is that the pin assignments have been made to
correspond to the pins on an 8-pin package for this part.
This enables more graceful use of an exported netlist in the
FreePCB PC layout program.

Tom Bruhns
2008-08-12
