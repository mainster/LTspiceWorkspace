add the command
.lib 74hc.lib 
for I/O 74hc subckt