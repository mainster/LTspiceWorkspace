PC/WINDOWS INSTALLATION STEPS
-----------------------------

1.  Copy all the files to the ORCAD\CAPTURE\LIBRARY\PSICE directory.

2.  Run ORCAD Schematics program.

3.  Select the PART...   option in the  PLACE  menu.

4.  Click on   ADD LIBRARY...   button.

5.  Search and select TRIAC_st.OLB or SCR_st.OLB or DIAC_st.OLB or ACST.OLB or ACS.OLB file.

6.  Press the OPEN button. The symbols will be automatically loaded.

7.  Press CANCEL button.

8.  Now, select EDIT SIMULATION PROFILE  option in the PSPICE menu.

9.  Select LIBRARY option in  Configuration files  menu.

10. Click BROWSE... button

11. Search and select the Triac_st.LIB or Scr_st.LIB or Diac_st.LIB or acst.lib or acs.lib file.

12. Press the OPEN button.

13. Press the  ADD AS GLOBAL button.

14. Press the OK button.

15. Congratulations, you are now ready to use your new 
    STMicroelectronics model library.

